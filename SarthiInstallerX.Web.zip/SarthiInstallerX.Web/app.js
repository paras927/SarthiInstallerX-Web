const apps = [
  { name: "VaultSync Dashboard", apk: "vaultsync.apk" },
  { name: "Gesture RC Controller", apk: "rccontrol.apk" },
  { name: "ChronoTracker", apk: "chrono.apk" },
];

const container = document.getElementById("app-list");

apps.forEach((app) => {
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `
    <h2>${app.name}</h2>
    <p>Ready to install</p>
    <button onclick="installApp('${app.apk}')">Install</button>
  `;
  container.appendChild(card);
});

function installApp(apkName) {
  alert(`Triggering install for ${apkName}`);
  // Replace this with native install trigger or file download
  window.location.href = apkName;
}

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("service-worker.js");
}